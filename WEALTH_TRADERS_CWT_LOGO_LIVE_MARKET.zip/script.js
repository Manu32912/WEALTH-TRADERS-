function menu(){const nav=document.querySelector("nav");if(nav)nav.classList.toggle("open")}
function save(k,v){localStorage.setItem(k,v)}
function get(k,d=""){const v=localStorage.getItem(k);return v===null?d:v}
function choosePlan(amount,target){save("wt_plan",amount);save("wt_target",target);location.href="signup.html?plan=selected"}
function chooseVip(pkg){save("wt_vip",pkg);location.href="payment.html"}
function register(e){e.preventDefault();const name=document.getElementById("name").value.trim(),email=document.getElementById("email").value.trim().toLowerCase(),phone=document.getElementById("phone").value.trim(),password=document.getElementById("password").value;if(!name||!email||!phone||!password)return;save("wt_name",name);save("wt_email",email);save("wt_phone",phone);save("wt_password",password);save("wt_logged","true");location.href="dashboard.html"}
function login(e){e.preventDefault();const email=document.getElementById("loginEmail").value.trim().toLowerCase(),password=document.getElementById("loginPassword").value;if(email===get("wt_email")&&password===get("wt_password")){save("wt_logged","true");location.href="dashboard.html"}else alert("Email or password is incorrect. Please register first or check your details.")}
function logout(){localStorage.removeItem("wt_logged");location.href="index.html"}
function loadDash(){const ids={dashName:get("wt_name","Guest"),dashEmail:get("wt_email","Not registered"),dashPhone:get("wt_phone","Not registered"),dashStatus:get("wt_logged")?"Active":"Guest",dashPlan:get("wt_plan","None"),dashTarget:get("wt_target","None"),dashVip:get("wt_vip","None")};Object.keys(ids).forEach(id=>{const el=document.getElementById(id);if(el)el.textContent=ids[id]})}
function faq(el){const a=el.nextElementSibling;if(a)a.style.display=a.style.display==="block"?"none":"block"}
(function(){const c=document.createElement('canvas');c.id='marketCanvas';document.body.prepend(c);const ctx=c.getContext('2d');let W,H,candles=[];function resize(){W=innerWidth;H=innerHeight;c.width=W*devicePixelRatio;c.height=H*devicePixelRatio;c.style.width=W+'px';c.style.height=H+'px';ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);candles=[];for(let i=-2;i<W/18+3;i++)candles.push({x:i*18+Math.random()*5,base:H*.2+Math.random()*H*.7,v:(Math.random()-.5)*9})}function draw(){ctx.clearRect(0,0,W,H);ctx.globalAlpha=document.body.classList.contains('home-page')?.16:.07;candles.forEach(d=>{d.x-=.18;if(d.x<-20)d.x=W+20;d.base+=d.v*.04;if(d.base<100||d.base>H-80)d.v*=-1;const up=Math.random()>.48,body=10+Math.random()*28,wick=body*1.6;ctx.strokeStyle=up?'#20df48':'#ff2935';ctx.fillStyle=up?'#20df48':'#ff2935';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(d.x,d.base-wick);ctx.lineTo(d.x,d.base+wick);ctx.stroke();ctx.fillRect(d.x-3,d.base-(up?body:0),6,body)});ctx.globalAlpha=1;requestAnimationFrame(draw)}resize();addEventListener('resize',resize);draw()})();

// Live crypto market prices. Prices are fetched in the visitor's browser so the ticker stays current.
async function loadLiveMarket(){
  const ticker=document.getElementById('liveTicker');
  if(!ticker)return;
  const ids=['bitcoin','ethereum','binancecoin','solana'].join(',');
  try{
    const r=await fetch('https://api.coingecko.com/api/v3/simple/price?ids='+ids+'&vs_currencies=usd&include_24hr_change=true',{cache:'no-store'});
    if(!r.ok)throw new Error('Market API unavailable');
    const data=await r.json();
    Object.entries(data).forEach(([id,v])=>{
      const card=ticker.querySelector('[data-coin="'+id+'"]');
      if(!card)return;
      const price=card.querySelector('.price'), change=card.querySelector('.change');
      if(price)price.textContent=new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:v.usd>=1000?2:v.usd>=1?2:6}).format(v.usd);
      if(change){const c=Number(v.usd_24h_change||0);change.textContent=(c>=0?'+':'')+c.toFixed(2)+'%';change.classList.toggle('up',c>=0);change.classList.toggle('down',c<0)}
    });
    const live=ticker.querySelector('em'); if(live)live.innerHTML='● Live Market · updated '+new Date().toLocaleTimeString();
  }catch(e){
    const live=ticker.querySelector('em'); if(live)live.innerHTML='● Live Market · data temporarily unavailable';
  }
}
loadLiveMarket();
setInterval(loadLiveMarket,30000);
