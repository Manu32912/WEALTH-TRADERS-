function menu(){const nav=document.querySelector("nav");if(nav)nav.classList.toggle("open")}
function save(k,v){localStorage.setItem(k,v)}
function get(k,d=""){const v=localStorage.getItem(k);return v===null?d:v}
function choosePlan(amount,target){save("wt_plan",amount);save("wt_target",target);location.href="signup.html?plan=selected"}
function chooseVip(pkg){save("wt_vip",pkg);location.href="payment.html"}
function register(e){e.preventDefault();const name=document.getElementById("name").value.trim(),email=document.getElementById("email").value.trim().toLowerCase(),phone=document.getElementById("phone").value.trim(),password=document.getElementById("password").value;if(!name||!email||!phone||!password)return;save("wt_name",name);save("wt_email",email);save("wt_phone",phone);save("wt_password",password);save("wt_logged","true");location.href="dashboard.html"}
function login(e){e.preventDefault();const email=document.getElementById("loginEmail").value.trim().toLowerCase(),password=document.getElementById("loginPassword").value;if(email===get("wt_email")&&password===get("wt_password")){save("wt_logged","true");location.href="dashboard.html"}else alert("Email or password is incorrect. Please register first or check your details.")}
function logout(){localStorage.removeItem("wt_logged");location.href="index.html"}
function loadDash(){const ids={dashName:get("wt_name","Guest"),dashEmail:get("wt_email","Not registered"),dashPhone:get("wt_phone","Not registered"),dashStatus:get("wt_logged")?"Active":"Guest",dashPlan:get("wt_plan","None"),dashTarget:get("wt_target","None"),dashVip:get("wt_vip","None")};Object.keys(ids).forEach(id=>{const el=document.getElementById(id);if(el)el.textContent=ids[id]})}
function faq(el){const a=el.nextElementSibling;if(a)a.style.display=a.style.display==="block"?"none":"block"}
// Live crypto market prices via Binance public market feeds.
// WebSocket provides near-real-time updates; REST is used as a fallback.
const marketSymbols={
  bitcoin:'BTCUSDT',
  ethereum:'ETHUSDT',
  binancecoin:'BNBUSDT',
  solana:'SOLUSDT'
};
const marketNames=Object.fromEntries(Object.entries(marketSymbols).map(([k,v])=>[v,k]));
let marketSocket=null;

function formatMarketPrice(v){
  const n=Number(v);
  const digits=n>=1000?2:n>=1?2:6;
  return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:digits}).format(n);
}
function updateMarketCard(key,price,change){
  const ticker=document.getElementById('liveTicker');
  if(!ticker)return;
  const card=ticker.querySelector('[data-coin="'+key+'"]');
  if(!card)return;
  const pe=card.querySelector('.price'), ce=card.querySelector('.change');
  if(pe)pe.textContent=formatMarketPrice(price);
  if(ce){
    const c=Number(change||0);
    ce.textContent=(c>=0?'+':'')+c.toFixed(2)+'%';
    ce.classList.toggle('up',c>=0); ce.classList.toggle('down',c<0);
  }
}
function setMarketStatus(text){
  const live=document.querySelector('#liveTicker em');
  if(live)live.innerHTML='● '+text;
}

async function loadLiveMarket(){
  const ticker=document.getElementById('liveTicker');
  if(!ticker)return;
  try{
    const symbols=Object.values(marketSymbols).map(s=>'"'+s+'"').join(',');
    const r=await fetch('https://api.binance.com/api/v3/ticker/24hr?symbols=['+symbols+']',{cache:'no-store'});
    if(!r.ok)throw new Error('REST market unavailable');
    const rows=await r.json();
    rows.forEach(row=>updateMarketCard(marketNames[row.symbol],row.lastPrice,row.priceChangePercent));
    setMarketStatus('Live Market · updated '+new Date().toLocaleTimeString());
  }catch(e){
    // WebSocket may still be connected; don't overwrite working values.
    setMarketStatus('Live Market · connecting…');
  }
}
function connectLiveMarket(){
  if(!('WebSocket' in window))return;
  try{
    const streams=Object.values(marketSymbols).map(s=>s.toLowerCase()+'@ticker').join('/');
    marketSocket=new WebSocket('wss://stream.binance.com:9443/stream?streams='+streams);
    marketSocket.onopen=()=>setMarketStatus('Live Market · connected');
    marketSocket.onmessage=e=>{
      try{
        const row=JSON.parse(e.data).data;
        const key=marketNames[row.s];
        if(key)updateMarketCard(key,row.c,row.P);
        setMarketStatus('Live Market · real-time');
      }catch(_){ }
    };
    marketSocket.onclose=()=>{ setMarketStatus('Live Market · reconnecting…'); setTimeout(connectLiveMarket,5000); };
    marketSocket.onerror=()=>{ try{marketSocket.close()}catch(_){} };
  }catch(_){ }
}
loadLiveMarket();
connectLiveMarket();
setInterval(loadLiveMarket,60000);
