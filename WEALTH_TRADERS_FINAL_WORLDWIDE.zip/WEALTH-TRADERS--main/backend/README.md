# Wealth Traders backend

This backend provides server-side registration/login, password hashing, sessions, member dashboard data, investment selections and VIP membership selections.

## Deploy
1. Create a PostgreSQL database.
2. Set `DATABASE_URL`, `SESSION_SECRET`, `FRONTEND_ORIGIN` and `PORT` in your hosting provider.
3. Run `npm install` then `npm start`.
4. Run `schema.sql` against the PostgreSQL database.
5. The frontend currently uses a same-origin API by default. After deploying the backend separately, set `window.WT_API_BASE` to the HTTPS backend URL before `script.js` loads, or replace `API_BASE` in `script.js` with that URL.

GitHub Pages cannot run this Node.js server or PostgreSQL database.
