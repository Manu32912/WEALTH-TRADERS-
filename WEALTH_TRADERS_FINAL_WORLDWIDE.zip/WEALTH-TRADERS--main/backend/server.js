require('dotenv').config();
const express=require('express');
const cors=require('cors');
const session=require('express-session');
const PgSession=require('connect-pg-simple')(session);
const {Pool}=require('pg');
const bcrypt=require('bcryptjs');
const fs=require('fs');
const path=require('path');

const app=express();
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL && !process.env.DATABASE_URL.includes('localhost') ? {rejectUnauthorized:false}:false});
const allowed=(process.env.FRONTEND_ORIGIN||'https://manu32912.github.io').split(',').map(x=>x.trim());
app.use(cors({origin:(origin,cb)=>{if(!origin||allowed.includes(origin))return cb(null,true);cb(new Error('Origin not allowed'));},credentials:true}));
app.use(express.json({limit:'50kb'}));
app.use(session({store:new PgSession({pool,tableName:'user_sessions',createTableIfMissing:true}),secret:process.env.SESSION_SECRET,resave:false,saveUninitialized:false,cookie:{httpOnly:true,secure:true,sameSite:'none',maxAge:1000*60*60*24*7}}));

async function me(req,res,next){
  if(!req.session.userId)return res.status(401).json({error:'Please log in.'});
  const q=await pool.query(`SELECT u.id,u.name,u.email,u.phone,u.last_seen,
    i.amount,i.target,i.status AS investment_status,
    v.package_name,v.status AS vip_status
    FROM users u LEFT JOIN LATERAL (SELECT * FROM investments WHERE user_id=u.id ORDER BY id DESC LIMIT 1) i ON true
    LEFT JOIN LATERAL (SELECT * FROM vip_memberships WHERE user_id=u.id ORDER BY id DESC LIMIT 1) v ON true
    WHERE u.id=$1`,[req.session.userId]);
  if(!q.rowCount)return res.status(401).json({error:'Account not found.'});
  await pool.query('UPDATE users SET last_seen=NOW() WHERE id=$1',[req.session.userId]);
  req.user=q.rows[0]; next();
}

app.get('/health',(req,res)=>res.json({ok:true}));
app.post('/api/auth/register',async(req,res)=>{
  try{
    const {name,email,phone,password}=req.body;
    if(!name||!email||!phone||!password)return res.status(400).json({error:'All fields are required.'});
    if(!/^\+[1-9]\d{7,14}$/.test(String(phone).replace(/[\s()-]/g,'')))return res.status(400).json({error:'Use a valid international phone number with country code.'});
    if(String(password).length<8)return res.status(400).json({error:'Password must be at least 8 characters.'});
    const exists=await pool.query('SELECT 1 FROM users WHERE email=$1 OR phone=$2',[email.toLowerCase(),phone]);
    if(exists.rowCount)return res.status(409).json({error:'Email or phone number is already registered.'});
    const hash=await bcrypt.hash(password,12);
    const q=await pool.query('INSERT INTO users(name,email,phone,password_hash) VALUES($1,$2,$3,$4) RETURNING id,name,email,phone',[name,email.toLowerCase(),phone,hash]);
    res.status(201).json({user:q.rows[0]});
  }catch(e){console.error(e);res.status(500).json({error:'Registration failed.'});}
});
app.post('/api/auth/login',async(req,res)=>{
  try{
    const {email,password}=req.body; const q=await pool.query('SELECT * FROM users WHERE email=$1',[String(email||'').toLowerCase()]);
    if(!q.rowCount||!(await bcrypt.compare(password||'',q.rows[0].password_hash)))return res.status(401).json({error:'Invalid email or password.'});
    req.session.userId=q.rows[0].id; await pool.query('UPDATE users SET last_seen=NOW() WHERE id=$1',[q.rows[0].id]);
    res.json({ok:true});
  }catch(e){console.error(e);res.status(500).json({error:'Login failed.'});}
});
app.post('/api/auth/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',me,(req,res)=>{const u=req.user;res.json({user:{name:u.name,email:u.email,phone:u.phone,online:true,investment:u.amount?{amount:u.amount,target:u.target,status:u.investment_status}:null,vip:u.package_name?{packageName:u.package_name,status:u.vip_status}:null}})});
app.post('/api/investments/select',me,async(req,res)=>{const {amount,target}=req.body;if(!amount||!target)return res.status(400).json({error:'Investment selection is incomplete.'});await pool.query('INSERT INTO investments(user_id,amount,target) VALUES($1,$2,$3)',[req.session.userId,amount,target]);res.json({ok:true});});
app.post('/api/vip/select',me,async(req,res)=>{const {packageName}=req.body;if(!packageName)return res.status(400).json({error:'VIP package is required.'});await pool.query('INSERT INTO vip_memberships(user_id,package_name) VALUES($1,$2)',[req.session.userId,packageName]);res.json({ok:true});});

app.listen(process.env.PORT||3000,()=>console.log('Wealth Traders backend running'));
