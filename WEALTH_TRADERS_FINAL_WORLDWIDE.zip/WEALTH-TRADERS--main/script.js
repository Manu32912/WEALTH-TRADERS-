/* Wealth Traders frontend helpers. Set API_BASE after deploying the backend. */
const API_BASE = window.WT_API_BASE || "";

function api(path, options={}) {
  const headers = Object.assign({"Content-Type":"application/json"}, options.headers || {});
  return fetch(API_BASE + path, Object.assign({}, options, {headers, credentials:"include"}))
    .then(async r => {
      const data = await r.json().catch(()=>({}));
      if (!r.ok) throw new Error(data.error || `Request failed (${r.status})`);
      return data;
    });
}

function get(key){ try{return JSON.parse(localStorage.getItem(key));}catch(e){return null;} }
function set(key,value){ localStorage.setItem(key,JSON.stringify(value)); }
function menu(){ const nav=document.querySelector('.nav'); if(nav) nav.classList.toggle('open'); }
function faq(el){ const item=el.closest('.faqitem'); if(item) item.classList.toggle('open'); }

function choosePlan(amount,target){
  set("wt_selected_plan",{amount,target});
  window.location.href="payment.html?type=investment";
}
function chooseVip(plan){
  set("wt_vip",plan);
  window.location.href="payment.html?type=vip";
}

async function syncSelection(){
  const plan=get("wt_selected_plan");
  const vip=get("wt_vip");
  if(!plan && !vip) return null;
  const me=await api("/api/me");
  if(plan){ await api("/api/investments/select",{method:"POST",body:JSON.stringify(plan)}); localStorage.removeItem("wt_selected_plan"); }
  if(vip){ await api("/api/vip/select",{method:"POST",body:JSON.stringify({packageName:vip})}); localStorage.removeItem("wt_vip"); }
  return me.user;
}

async function register(event){
  event.preventDefault();
  const btn=event.target.querySelector('button'); btn.disabled=true; btn.textContent='Creating…';
  const phone=document.getElementById('phone').value.trim().replace(/[\s()-]/g,'');
  if(!/^\+[1-9]\d{7,14}$/.test(phone)){
    alert('Enter a valid international phone number with country code, for example +254..., +44... or +1...');
    btn.disabled=false; btn.textContent='Create Account'; return;
  }
  try{
    await api('/api/auth/register',{method:'POST',body:JSON.stringify({
      name:document.getElementById('name').value.trim(),
      email:document.getElementById('email').value.trim(),
      phone,
      password:document.getElementById('password').value
    })});
    alert('Account created successfully. You can now log in.');
    window.location.href='login.html';
  }catch(e){ alert(e.message); btn.disabled=false; btn.textContent='Create Account'; }
}

async function login(event){
  event.preventDefault();
  const btn=event.target.querySelector('button'); btn.disabled=true; btn.textContent='Signing in…';
  try{
    await api('/api/auth/login',{method:'POST',body:JSON.stringify({
      email:document.getElementById('loginEmail').value.trim(),
      password:document.getElementById('loginPassword').value
    })});
    window.location.href='dashboard.html';
  }catch(e){ alert(e.message); btn.disabled=false; btn.textContent='Login'; }
}

async function logout(){ try{await api('/api/auth/logout',{method:'POST'});}catch(e){} window.location.href='login.html'; }

async function loadDash(){
  try{
    const r=await api('/api/me'); const u=r.user;
    document.getElementById('dashName').textContent=u.name||'—';
    document.getElementById('dashEmail').textContent=u.email||'—';
    document.getElementById('dashPhone').textContent=u.phone||'—';
    document.getElementById('dashStatus').innerHTML='<span class="online-dot"></span>Online';
    document.getElementById('dashStatus').classList.add('status-online');
    document.getElementById('dashPlan').textContent=u.investment ? `${u.investment.amount}` : 'No investment selected';
    document.getElementById('dashTarget').textContent=u.investment ? `${u.investment.target}` : '—';
    document.getElementById('dashVip').textContent=u.vip?.status==='paid' ? 'Paid' : (u.vip ? 'Pending verification' : 'Not joined');
  }catch(e){
    document.getElementById('dashStatus').textContent='Not signed in';
    ['dashPlan','dashTarget','dashVip'].forEach(id=>document.getElementById(id).textContent='—');
    setTimeout(()=>window.location.href='login.html',900);
  }
}

function money(n){ return '$'+Number(n).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}); }
async function updateTicker(){
  const map={bitcoin:'BTCUSDT',ethereum:'ETHUSDT',binancecoin:'BNBUSDT',solana:'SOLUSDT'};
  try{
    const symbols=Object.values(map).map(x=>`"${x}"`).join(',');
    const r=await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbols=[${symbols}]`);
    if(!r.ok) throw new Error('market');
    const rows=await r.json();
    const by=Object.fromEntries(rows.map(x=>[x.symbol,x]));
    document.querySelectorAll('#liveTicker [data-coin]').forEach(el=>{
      const row=by[map[el.dataset.coin]]; if(!row)return;
      const price=el.querySelector('.price'), change=el.querySelector('.change');
      price.textContent=money(row.lastPrice);
      const pct=Number(row.priceChangePercent); change.textContent=(pct>=0?'+':'')+pct.toFixed(2)+'%';
      change.classList.toggle('up',pct>=0); change.classList.toggle('down',pct<0);
    });
  }catch(e){
    document.querySelectorAll('#liveTicker .price').forEach(x=>{if(x.textContent==='Loading…')x.textContent='Market unavailable';});
  }
}

window.addEventListener('load',()=>{ if(document.getElementById('liveTicker')){updateTicker();setInterval(updateTicker,15000);} });
