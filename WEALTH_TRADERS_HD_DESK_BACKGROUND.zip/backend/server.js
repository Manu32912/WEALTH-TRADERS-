
require("dotenv").config();
const express=require("express"), cors=require("cors"), helmet=require("helmet");
const rateLimit=require("express-rate-limit"), bcrypt=require("bcryptjs"), jwt=require("jsonwebtoken");
const cookieParser=require("cookie-parser"), {Pool}=require("pg");

const app=express();
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_SSL==="false"?false:{rejectUnauthorized:false}});
const FRONTEND_ORIGIN=process.env.FRONTEND_ORIGIN;
const JWT_SECRET=process.env.JWT_SECRET;
if(!JWT_SECRET) throw new Error("JWT_SECRET is required");

app.use(helmet());
app.use(express.json({limit:"20kb"}));
app.use(cookieParser());
app.use(cors({origin:FRONTEND_ORIGIN,credentials:true}));
app.use("/api/auth",rateLimit({windowMs:15*60*1000,max:50,standardHeaders:true,legacyHeaders:false}));

async function init(){
 await pool.query(`CREATE TABLE IF NOT EXISTS users(
   id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,
   phone TEXT NOT NULL,password_hash TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
   last_seen TIMESTAMPTZ
 )`);
 await pool.query(`CREATE TABLE IF NOT EXISTS investments(
   id BIGSERIAL PRIMARY KEY,user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
   amount_usd NUMERIC(14,2) NOT NULL,target_usd NUMERIC(14,2),
   status TEXT NOT NULL DEFAULT 'pending',created_at TIMESTAMPTZ NOT NULL DEFAULT now()
 )`);
 await pool.query(`CREATE TABLE IF NOT EXISTS vip_memberships(
   id BIGSERIAL PRIMARY KEY,user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
   package TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',
   created_at TIMESTAMPTZ NOT NULL DEFAULT now()
 )`);
}
function tokenFor(u){return jwt.sign({sub:String(u.id)},JWT_SECRET,{expiresIn:"7d"})}
function setAuth(res,token){res.cookie("wt_session",token,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"none",maxAge:7*24*60*60*1000})}
function auth(req,res,next){
 try{req.user=jwt.verify(req.cookies.wt_session,JWT_SECRET);next()}catch{return res.status(401).json({error:"Not authenticated"})}
}
app.get("/api/health",(req,res)=>res.json({ok:true}));
app.post("/api/auth/register",async(req,res)=>{
 const {name,email,phone,password}=req.body||{};
 if(!name||!email||!phone||!password)return res.status(400).json({error:"All fields are required"});
 if(!/^\+44\d{9,10}$/.test(phone))return res.status(400).json({error:"Use a valid UK +44 mobile number"});
 if(password.length<8)return res.status(400).json({error:"Password must be at least 8 characters"});
 try{
   const hash=await bcrypt.hash(password,12);
   const r=await pool.query("INSERT INTO users(name,email,phone,password_hash,last_seen) VALUES($1,$2,$3,$4,now()) RETURNING id,name,email,phone",[
     name.trim(),email.toLowerCase().trim(),phone.trim(),hash
   ]);
   const u=r.rows[0]; setAuth(res,tokenFor(u)); res.json({user:u});
 }catch(e){if(e.code==="23505")return res.status(409).json({error:"Email already registered"});console.error(e);res.status(500).json({error:"Registration failed"})}
});
app.post("/api/auth/login",async(req,res)=>{
 const {email,password}=req.body||{};
 const r=await pool.query("SELECT * FROM users WHERE email=$1",[String(email||"").toLowerCase().trim()]);
 const u=r.rows[0];
 if(!u || !(await bcrypt.compare(password||"",u.password_hash)))return res.status(401).json({error:"Invalid email or password"});
 await pool.query("UPDATE users SET last_seen=now() WHERE id=$1",[u.id]);
 const safe={id:u.id,name:u.name,email:u.email,phone:u.phone}; setAuth(res,tokenFor(safe)); res.json({user:safe});
});
app.post("/api/auth/logout",(req,res)=>{res.clearCookie("wt_session",{httpOnly:true,sameSite:"none",secure:process.env.NODE_ENV==="production"});res.json({ok:true})});
app.get("/api/me",auth,async(req,res)=>{
 const ur=await pool.query("SELECT id,name,email,phone,last_seen FROM users WHERE id=$1",[req.user.sub]);
 if(!ur.rows[0])return res.status(401).json({error:"Account not found"});
 await pool.query("UPDATE users SET last_seen=now() WHERE id=$1",[req.user.sub]);
 const ir=await pool.query("SELECT amount_usd,target_usd,status,created_at FROM investments WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1",[req.user.sub]);
 const vr=await pool.query("SELECT package,status,created_at FROM vip_memberships WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1",[req.user.sub]);
 const u=ur.rows[0];
 res.json({user:{
   id:u.id,name:u.name,email:u.email,phone:u.phone,
   online:true,
   investment:ir.rows[0]?{amount:"$"+Number(ir.rows[0].amount_usd).toLocaleString(),target:"$"+Number(ir.rows[0].target_usd||0).toLocaleString(),status:ir.rows[0].status}:null,
   vip:vr.rows[0]||null
 }});
});
app.post("/api/investments/select",auth,async(req,res)=>{
 const {amount,target}=req.body||{};
 const a=Number(String(amount||"").replace(/[$,]/g,"")), t=Number(String(target||"").replace(/[$,]/g,""));
 if(!Number.isFinite(a)||a<=0||!Number.isFinite(t)||t<=0)return res.status(400).json({error:"Invalid plan"});
 await pool.query("INSERT INTO investments(user_id,amount_usd,target_usd) VALUES($1,$2,$3)",[req.user.sub,a,t]);
 res.json({ok:true});
});
app.post("/api/vip/select",auth,async(req,res)=>{
 const {packageName}=req.body||{}; if(!packageName)return res.status(400).json({error:"Package required"});
 await pool.query("INSERT INTO vip_memberships(user_id,package,status) VALUES($1,$2,'pending')",[req.user.sub,packageName]);
 res.json({ok:true,status:"pending"});
});
app.listen(process.env.PORT||3000,()=>console.log("Auth API listening"));
init().catch(e=>{console.error(e);process.exit(1)});
