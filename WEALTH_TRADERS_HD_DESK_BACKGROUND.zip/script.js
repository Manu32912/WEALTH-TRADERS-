
const API_BASE = window.WEALTH_API_BASE || "https://YOUR-BACKEND-DOMAIN.example.com";

function menu(){document.querySelector("header .nav")?.classList.toggle("open")}
function set(k,v){localStorage.setItem(k,JSON.stringify(v))}
function get(k,d=null){try{return JSON.parse(localStorage.getItem(k)) ?? d}catch{return d}}
function choosePlan(amount,target){
  set("wt_selected_plan",{amount,target});
  window.location.href="payment.html?type=investment";
}
function chooseVip(plan){
  set("wt_vip",plan);
  window.location.href="payment.html?type=vip";
}
async function syncSelection(){
  try{
    const r=await api("/api/me");
    const plan=get("wt_selected_plan");
    const vip=get("wt_vip");
    if(plan){
      await api("/api/investments/select",{method:"POST",body:JSON.stringify(plan)});
      localStorage.removeItem("wt_selected_plan");
    }
    if(vip){
      await api("/api/vip/select",{method:"POST",body:JSON.stringify({packageName:vip})});
      localStorage.removeItem("wt_vip");
    }
    return r.user;
  }catch(e){ return null; }
}
function faq(el){el.parentElement.classList.toggle("open")}

async function api(path, options={}){
  const res=await fetch(API_BASE + path,{
    credentials:"include",
    headers:{"Content-Type":"application/json",...(options.headers||{})},
    ...options
  });
  let data={}; try{data=await res.json()}catch{}
  if(!res.ok) throw new Error(data.error||"Request failed");
  return data;
}

async function register(e){
  e.preventDefault();
  const body={
    name:document.getElementById("name").value.trim(),
    email:document.getElementById("email").value.trim(),
    phone:document.getElementById("phone").value.trim(),
    password:document.getElementById("password").value
  };
  if(!/^\+[1-9]\d{7,14}$/.test(body.phone)){alert("Please enter a valid international phone number with country code, for example +254712345678.");return}
  try{
    const data=await api("/api/auth/register",{method:"POST",body:JSON.stringify(body)});
    set("wt_user",data.user); window.location.href="dashboard.html";
  }catch(err){alert(err.message)}
}

async function login(e){
  e.preventDefault();
  try{
    const data=await api("/api/auth/login",{method:"POST",body:JSON.stringify({
      email:document.getElementById("loginEmail").value.trim(),
      password:document.getElementById("loginPassword").value
    })});
    set("wt_user",data.user); window.location.href="dashboard.html";
  }catch(err){alert(err.message)}
}

async function logout(){
  try{await api("/api/auth/logout",{method:"POST"})}catch{}
  localStorage.removeItem("wt_user"); window.location.href="index.html";
}

async function loadDash(){
  try{
    const {user}=await api("/api/me");
    document.getElementById("dashName").textContent=user.name;
    document.getElementById("dashEmail").textContent=user.email;
    document.getElementById("dashPhone").textContent=user.phone;
    document.getElementById("dashStatus").innerHTML='<span class="online-dot"></span>Online';
    document.getElementById("dashStatus").classList.add("status-online");
    document.getElementById("dashPlan").textContent=user.investment ? user.investment.amount : "None";
    document.getElementById("dashTarget").textContent=user.investment ? (user.investment.target+" (stated target)") : "None";
    document.getElementById("dashVip").textContent=user.vip?.status==="paid" ? "Paid" : (user.vip?.status==="pending" ? "Pending verification" : "Not paid");
  }catch(err){
    document.getElementById("dashStatus").textContent="Not signed in";
  }
}

async function liveMarket(){
  const ids=["bitcoin","ethereum","binancecoin","solana"];
  const cards=[...document.querySelectorAll("#liveTicker [data-coin]")];
  if(!cards.length)return;
  try{
    const r=await fetch("https://api.coingecko.com/api/v3/simple/price?ids="+ids.join(",")+"&vs_currencies=usd&include_24hr_change=true",{cache:"no-store"});
    const d=await r.json();
    cards.forEach(c=>{
      const x=d[c.dataset.coin]; if(!x)return;
      const p=c.querySelector(".price"), ch=c.querySelector(".change");
      p.textContent="$"+Number(x.usd).toLocaleString(undefined,{maximumFractionDigits:x.usd<1?6:2});
      ch.textContent=(x.usd_24h_change>=0?"+":"")+Number(x.usd_24h_change).toFixed(2)+"%";
      ch.classList.toggle("up",x.usd_24h_change>=0); ch.classList.toggle("down",x.usd_24h_change<0);
    });
  }catch(e){cards.forEach(c=>{c.querySelector(".change").textContent="Unavailable";c.querySelector(".price").textContent="—"})}
}
document.addEventListener("DOMContentLoaded",()=>{liveMarket();setInterval(liveMarket,30000)});
