const API_BASE = window.WEALTH_API_BASE || "";

function menu(){
  document.querySelector("header .nav")?.classList.toggle("open");
}

function setStored(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
function getStored(k,d=null){ try{ return JSON.parse(localStorage.getItem(k)) ?? d; }catch(e){ return d; } }

function choosePlan(amount, target){
  setStored("wt_selected_plan", {amount, target});
  window.location.href = "payment.html?type=investment";
}

function chooseVip(plan){
  setStored("wt_vip", plan);
  window.location.href = "payment.html?type=vip";
}

function faq(el){
  const item = el?.parentElement;
  if(item) item.classList.toggle("open");
}

async function api(path, options={}){
  if(!API_BASE) throw new Error("Backend is not connected yet.");
  const res = await fetch(API_BASE + path, {
    credentials:"include",
    headers:{"Content-Type":"application/json", ...(options.headers || {})},
    ...options
  });
  let data={}; try{ data=await res.json(); }catch(e){}
  if(!res.ok) throw new Error(data.message || data.error || "Request failed");
  return data;
}

async function register(e){
  e.preventDefault();
  const body={
    name: document.getElementById("name")?.value.trim(),
    email: document.getElementById("email")?.value.trim(),
    phone: document.getElementById("phone")?.value.trim(),
    password: document.getElementById("password")?.value
  };
  if(!/^\+[1-9]\d{7,14}$/.test(body.phone || "")){
    alert("Enter a valid international phone number, including the country code (for example +254..., +44..., or +1...).");
    return;
  }
  try{
    const data=await api("/api/auth/register",{method:"POST",body:JSON.stringify(body)});
    setStored("wt_user",data.user); window.location.href="dashboard.html";
  }catch(err){ alert(err.message); }
}

async function login(e){
  e.preventDefault();
  try{
    await api("/api/auth/login",{method:"POST",body:JSON.stringify({
      email:document.getElementById("loginEmail")?.value.trim(),
      password:document.getElementById("loginPassword")?.value
    })});
    window.location.href="dashboard.html";
  }catch(err){ alert(err.message); }
}

async function logout(){
  try{ await api("/api/auth/logout",{method:"POST"}); }catch(e){}
  try{ localStorage.removeItem("wt_user"); }catch(e){}
  window.location.href="index.html";
}

async function loadDash(){
  try{
    const data=await api("/api/me");
    const u=data.user || {};
    const inv=data.investment || null;
    const vip=data.vip || null;
    const el=id=>document.getElementById(id);
    if(el("dashName")) el("dashName").textContent=u.name || "—";
    if(el("dashEmail")) el("dashEmail").textContent=u.email || "—";
    if(el("dashPhone")) el("dashPhone").textContent=u.phone || "—";
    if(el("dashStatus")) el("dashStatus").innerHTML='<span class="online-dot"></span>Online';
    if(el("dashPlan")) el("dashPlan").textContent=inv ? `$${Number(inv.amount).toLocaleString()}` : "None";
    if(el("dashTarget")) el("dashTarget").textContent=inv ? `$${Number(inv.target).toLocaleString()}` : "None";
    if(el("dashVip")) el("dashVip").textContent=vip ? vip.status : "Not selected";
  }catch(err){
    const el=document.getElementById("dashStatus");
    if(el) el.textContent="Not signed in";
  }
}

async function liveMarket(){
  const cards=[...document.querySelectorAll("#liveTicker [data-coin]")];
  if(!cards.length) return;
  try{
    const ids=cards.map(c=>c.dataset.coin).join(",");
    const r=await fetch("https://api.coingecko.com/api/v3/simple/price?ids="+ids+"&vs_currencies=usd&include_24hr_change=true",{cache:"no-store"});
    if(!r.ok) throw new Error("market unavailable");
    const d=await r.json();
    cards.forEach(c=>{
      const x=d[c.dataset.coin]; if(!x) return;
      const p=c.querySelector(".price"), ch=c.querySelector(".change");
      if(p) p.textContent="$"+Number(x.usd).toLocaleString(undefined,{maximumFractionDigits:x.usd<1?6:2});
      if(ch){
        ch.textContent=(x.usd_24h_change>=0?"+":"")+Number(x.usd_24h_change).toFixed(2)+"%";
        ch.classList.toggle("up",x.usd_24h_change>=0);
        ch.classList.toggle("down",x.usd_24h_change<0);
      }
    });
  }catch(e){
    cards.forEach(c=>{ const p=c.querySelector(".price"), ch=c.querySelector(".change"); if(p)p.textContent="—"; if(ch)ch.textContent="Unavailable"; });
  }
}

function loadPackage(){
  const type=new URLSearchParams(location.search).get("type");
  const plan=getStored("wt_selected_plan");
  const vip=getStored("wt_vip");
  const target=document.getElementById("selectedPackage");
  if(!target) return;
  if(type==="investment" && plan) target.textContent=`Investment ${plan.amount} — target ${plan.target}`;
  else if(type==="vip" && vip) target.textContent=vip;
}

document.addEventListener("DOMContentLoaded",()=>{
  liveMarket();
  setInterval(liveMarket,30000);
  loadPackage();
  if(document.getElementById("dashStatus")) loadDash();
});
