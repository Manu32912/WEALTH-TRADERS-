
function menu(){document.querySelector("nav").classList.toggle("open")}
function save(k,v){localStorage.setItem(k,v)}
function get(k,d=""){return localStorage.getItem(k)||d}
function choosePlan(amount,target){
 save("wt_plan",amount);save("wt_target",target);
 alert("Selected investment plan: "+amount+" — up to "+target);
 location.href="dashboard.html";
}
function chooseVip(pkg){
 save("wt_vip",pkg);
 alert("Selected VIP package: "+pkg+". Payment verification is required before VIP access is activated.");
 location.href="payment.html";
}
function register(e){
 e.preventDefault();
 save("wt_name",document.getElementById("name").value);
 save("wt_email",document.getElementById("email").value);
 save("wt_phone",document.getElementById("phone").value);
 save("wt_logged","true");
 alert("Account created successfully.");
 location.href="dashboard.html";
}
function login(e){
 e.preventDefault();
 const email=document.getElementById("loginEmail").value;
 if(email===get("wt_email")){
  save("wt_logged","true");alert("Login successful.");location.href="dashboard.html";
 }else alert("No matching account found. Please register first.");
}
function loadDash(){
 document.getElementById("dashName").textContent=get("wt_name","Guest");
 document.getElementById("dashEmail").textContent=get("wt_email","Not registered");
 document.getElementById("dashPhone").textContent=get("wt_phone","Not registered");
 document.getElementById("dashStatus").textContent=get("wt_logged")?"Active":"Guest";
 document.getElementById("dashPlan").textContent=get("wt_plan","None");
 document.getElementById("dashTarget").textContent=get("wt_target","None");
 document.getElementById("dashVip").textContent=get("wt_vip","None");
}
function faq(el){let a=el.nextElementSibling;a.style.display=a.style.display==="block"?"none":"block"}

/* Animated trading candlestick background */
(function(){
  function initMarketBackground(){
    if(document.getElementById("market-bg")) return;
    const canvas=document.createElement("canvas");
    canvas.id="market-bg";
    canvas.setAttribute("aria-hidden","true");
    document.body.prepend(canvas);
    const ctx=canvas.getContext("2d");
    let w=0,h=0,dpr=window.devicePixelRatio||1;
    const candles=[];
    function resize(){
      w=window.innerWidth; h=window.innerHeight;
      dpr=window.devicePixelRatio||1;
      canvas.width=w*dpr; canvas.height=h*dpr;
      canvas.style.width=w+"px"; canvas.style.height=h+"px";
      ctx.setTransform(dpr,0,0,dpr,0,0);
      const count=Math.ceil(w/32)+8;
      candles.length=0;
      let price=h*.48;
      for(let i=0;i<count;i++){
        const open=price;
        const move=(Math.random()-.48)*70;
        const close=open+move;
        const high=Math.min(open,close)-Math.random()*38-8;
        const low=Math.max(open,close)+Math.random()*38+8;
        candles.push({x:i*32+10,open,close,high,low,phase:Math.random()*6.28});
        price=close;
      }
    }
    function draw(t){
      ctx.clearRect(0,0,w,h);
      const gap=32, bodyW=9, speed=t*.018;
      candles.forEach((c,i)=>{
        const x=c.x-(speed%gap);
        const pulse=Math.sin(t*.001+c.phase)*2;
        const o=c.open+pulse, cl=c.close+pulse, hi=c.high+pulse, lo=c.low+pulse;
        const up=cl<o;
        ctx.globalAlpha=.20;
        ctx.lineWidth=1;
        ctx.strokeStyle=up ? "rgba(24,190,125,.9)" : "rgba(235,75,75,.9)";
        ctx.fillStyle=up ? "rgba(24,190,125,.35)" : "rgba(235,75,75,.35)";
        ctx.beginPath(); ctx.moveTo(x,hi); ctx.lineTo(x,lo); ctx.stroke();
        const y=Math.min(o,cl), bh=Math.max(5,Math.abs(cl-o));
        ctx.fillRect(x-bodyW/2,y,bodyW,bh);
      });
      ctx.globalAlpha=.08;
      ctx.strokeStyle="rgba(212,175,55,.45)";
      ctx.lineWidth=1;
      for(let y=80;y<h;y+=90){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
      requestAnimationFrame(draw);
    }
    resize();
    window.addEventListener("resize",resize);
    requestAnimationFrame(draw);
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",initMarketBackground);
  else initMarketBackground();
})();
