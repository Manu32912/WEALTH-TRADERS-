
function menu(){document.querySelector("nav").classList.toggle("open")}
function save(k,v){localStorage.setItem(k,v)}
function get(k,d=""){return localStorage.getItem(k)||d}
function choosePlan(amount,target){
 save("wt_plan",amount);save("wt_target",target);
 alert("Selected investment plan: "+amount+" — up to "+target);
 location.href="dashboard.html";
}
function chooseVip(pkg){
 save("wt_vip",pkg);
 alert("Selected VIP package: "+pkg+". Payment verification is required before VIP access is activated.");
 location.href="payment.html";
}
function register(e){
 e.preventDefault();
 save("wt_name",document.getElementById("name").value);
 save("wt_email",document.getElementById("email").value);
 save("wt_phone",document.getElementById("phone").value);
 save("wt_logged","true");
 alert("Account created successfully.");
 location.href="dashboard.html";
}
function login(e){
 e.preventDefault();
 const email=document.getElementById("loginEmail").value;
 if(email===get("wt_email")){
  save("wt_logged","true");alert("Login successful.");location.href="dashboard.html";
 }else alert("No matching account found. Please register first.");
}
function loadDash(){
 document.getElementById("dashName").textContent=get("wt_name","Guest");
 document.getElementById("dashEmail").textContent=get("wt_email","Not registered");
 document.getElementById("dashPhone").textContent=get("wt_phone","Not registered");
 document.getElementById("dashStatus").textContent=get("wt_logged")?"Active":"Guest";
 document.getElementById("dashPlan").textContent=get("wt_plan","None");
 document.getElementById("dashTarget").textContent=get("wt_target","None");
 document.getElementById("dashVip").textContent=get("wt_vip","None");
}
function faq(el){let a=el.nextElementSibling;a.style.display=a.style.display==="block"?"none":"block"}
